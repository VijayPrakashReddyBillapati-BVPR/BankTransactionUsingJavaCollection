package com.cg.bankapp.exception;

public class WrongMobileNumberException extends Exception {
	public WrongMobileNumberException() {
		System.out.println("Invalid mobile number");
	}
}
