package com.cg.bankapp.exception;

public class CustomerAleadyExistException extends Exception{
	public CustomerAleadyExistException() {
		System.out.println("Customer already exist exception.");
	}
}
